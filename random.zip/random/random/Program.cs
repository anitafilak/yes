﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace random
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program 28 véletlenszerű számokat generál 10 és -10 között. ");
            int[] szamok=new int[28];
            Random rnd = new Random();
            int pozitiv = 0;
            int negativ = 0;
            int eredmeny = 0;
            int het = 0;
            int melyik = 0;
            bool hamis=false;
            int nagyobb = -10;
            int kisebb = 10;

            for (int i = 0; i < 28; i++) 
            {
                int szam = rnd.Next(-10,11);
                szamok[i]=szam;
                eredmeny = pozitiv % 2;
                Console.WriteLine(szam);
                if (eredmeny != 0)
                {
                    pozitiv++;
                }

                else
                {
                   negativ++;
                }

                if (het == 7) ;
                {
                    het++;
                }

                if (szamok[i] == 0 && hamis == false) 
                {
                    melyik = i;
                    hamis = true;
                }
                
            }
            for (int i=0; i<28; i++) 
            {
                if (kisebb >= szamok[i])
                {
                    kisebb = szamok[i];
                }
                if (nagyobb <= szamok[i])
                {
                    nagyobb = szamok[i];
                }
            }
            Console.WriteLine("Legkisebb: " +kisebb +" Legnagyobb: " + nagyobb);
            Console.WriteLine("Hanyadik  0: "+ melyik + " Hány eleme hét:  " + het);
            Console.WriteLine("Pozitív számok: "+ pozitiv + "Negatív számok:"+ negativ);

            Console.ReadKey();
        }
        
    }
}
