﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace randomszamtalal
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program random számokat generál!(1 és 100 között)");
            Random rnd = new Random();
            int szam = rnd.Next(1, 101);

            Console.WriteLine("melyik számra gondoltam?");
            int gondol = 0;
            gondol = Convert.ToInt32(Console.ReadLine());

            while (gondol !=szam)
            {
                if (gondol < szam )
                {
                    Console.WriteLine("Nagyobb számra gondoltam!");

                }

                else if (gondol > szam)
                {
                    Console.WriteLine("Kisebb számra gondoltam!");
                }
                Console.WriteLine("A válasz:" + gondol);
                Console.ReadLine();
            }
            Console.WriteLine("erre a számra gondoltam: {0}", gondol );
            }
        }
    }


