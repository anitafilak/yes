﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace halas_hazi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program eltárolja a fogot halak adatait.");
            int[] halSuly = new int[14];
            int[] halHossz = new int[14];


            for (int i = 0; i < halSuly.Length;)
            {
                halHossz[i] = i;
            }
            {
                
              Console.WriteLine("Adja meg hogy hány dkg a fogott hal:");
              int Suly = Convert.ToInt32(Console.ReadLine());
              Console.WriteLine("Adja meg hogy hány cm a fogott hal:");
              int Hossz=Convert.ToInt32(Console.ReadLine());
            }


            if (true)
            {

            }
            {
                Console.WriteLine("Ez a hal nehezebb mint 70dkg");
            }
            Console.ReadLine();
        }
        
    }
}

