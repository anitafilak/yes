﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bekeres_osztalyatlag
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program a diákoknak az átlagját tárolja el!");
            Console.WriteLine("Hány diáknak a jegyét szeretnéd eltárolni?");
            int diak = Convert.ToInt32(Console.ReadLine()); 
            double[] osztalyzat = new double[diak]; 
            double atlag = 0; 
            double atlagN = 0; 
            for (int i = 0; i < diak; i++)
            {
                Console.WriteLine("Hányas lett az értékelése");
                double jegy = Convert.ToDouble(Console.ReadLine());
                osztalyzat[i] = jegy; 
                atlag = atlag + jegy; 
            }
            double eredmeny = atlag / diak; 
            for (int i = 0; i < diak; i++) 
            {
                if (eredmeny < osztalyzat[i])
                {
                    atlagN++; 
                }
            }
            Console.WriteLine("Ennyi az átlag: {0:0.00}, ", eredmeny);
            Console.WriteLine("Ennyi diák lett annál jobb: ", atlagN);
            Console.ReadLine();
        }
        
    }
    
    
} 
