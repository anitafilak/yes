﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hazi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program csak egész számokat olvas be és azokat be is számozza ");
            Console.Write("Adja meg a tömb méretét: ");
            int tombi = Convert.ToInt32(Console.ReadLine());



            int[] tomb = new int[tombi];



            for (int i = 0; i < tombi; i++)
            {
                Console.Write("Adja meg a(z) {0}. számot: ", i + 1);
                tomb[i] = Convert.ToInt32(Console.ReadLine());
            }



            Console.Write("Adjon meg a keresett számot: ");
            int keresSzam = Convert.ToInt32(Console.ReadLine());



            int keresSzamCount = 0;



            for (int i = 0; i < tombi; i++)
            {
                if (tomb[i] == keresSzam)
                {
                    keresSzamCount++;
                }
            }



            Console.WriteLine("{0} ennyiszer szerepel: {1} ", keresSzam, keresSzamCount);



            Console.ReadKey();
        }
    }
}
